import jax
import jax.numpy as jnp

x = jnp.array([1.0, 2.0, 3.0])
print(jax.version.__version__)
print(x * 2)
