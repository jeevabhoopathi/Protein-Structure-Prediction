import os
import re
import glob
import hashlib
import subprocess
import pandas as pd
from pathlib import Path
import streamlit as st
import py3Dmol
import streamlit.components.v1 as components

# === Helper Functions ===
def add_hash(x, y):
    return x + "_" + hashlib.sha1(y.encode()).hexdigest()[:5]

def check(folder):
    return not os.path.exists(folder)

def is_valid_sequence(seq):
    return re.fullmatch(r"[ACDEFGHIKLMNPQRSTVWY]+", seq.strip().upper()) is not None

def run_colabfold(jobname, sequence, use_amber=False, use_templates=False):
    os.makedirs(jobname, exist_ok=True)
    queries_path = os.path.join(jobname, f"{jobname}.csv")
    with open(queries_path, "w") as f:
        f.write(f"id,sequence\n{jobname},{sequence}")

    cmd = ["colabfold_batch", queries_path, jobname]
    if use_amber:
        cmd.append("--amber")
    if use_templates:
        cmd.append("--templates")

    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    return result

def show_structure_in_streamlit(pdb_path):
    with open(pdb_path, "r") as f:
        pdb_data = f.read()
    viewer = py3Dmol.view(width=800, height=600)
    viewer.addModel(pdb_data, "pdb")
    viewer.setStyle({"cartoon": {"color": "spectrum"}})
    viewer.zoomTo()
    components.html(viewer._make_html(), height=600, width=800)

# === Streamlit UI ===
st.set_page_config(layout="wide")
st.title("ColabFold Web Interface")

# Tabs: Input, Results, Viewer
tab1, tab2, tab3 = st.tabs(["Input", "Results", "3D Viewer"])

with tab1:
    st.header("Protein Prediction Input")
    user_sequence = st.text_area("Enter protein sequence (1-letter amino acid codes):", height=100)
    jobname_input = st.text_input("Job name:", value="test")
    amber_option = st.checkbox("Use AMBER relaxation", value=False)
    template_option = st.checkbox("Use templates", value=False)
    run_button = st.button("Run ColabFold")

    if run_button:
        user_sequence = user_sequence.strip().upper().replace(" ", "").replace("\n", "")
        if not is_valid_sequence(user_sequence):
            st.error("Invalid sequence. Only use standard amino acid 1-letter codes (ACDEFGHIKLMNPQRSTVWY).")
        else:
            basejobname = re.sub(r'\W+', '', jobname_input)
            jobname = add_hash(basejobname, user_sequence)
            if not check(jobname):
                i = 0
                while not check(f"{jobname}_{i}"):
                    i += 1
                jobname = f"{jobname}_{i}"
            try:
                with st.spinner("Running ColabFold..."):
                    result = run_colabfold(jobname, user_sequence, amber_option, template_option)
                st.success("ColabFold run completed.")
                st.session_state.jobname = jobname
                st.session_state.sequence = user_sequence
            except subprocess.CalledProcessError as e:
                st.error("ColabFold execution failed.")
                st.text(e.stdout)
                st.text(e.stderr)

with tab2:
    st.header("Prediction Summary")
    if "jobname" in st.session_state:
        st.markdown(f"**Job name:** `{st.session_state.jobname}`")
        st.markdown(f"**Sequence length:** `{len(st.session_state.sequence)}`")
        st.markdown("**Output files:**")
        output_files = glob.glob(os.path.join(st.session_state.jobname, "*"))
        for file in output_files:
            st.markdown(f"- `{os.path.basename(file)}`")
    else:
        st.info("No job has been run yet.")

with tab3:
    st.header("3D Protein Structure Viewer")
    if "jobname" in st.session_state:
        pdb_files = glob.glob(os.path.join(st.session_state.jobname, "*rank_001_*.pdb"))
        if pdb_files:
            show_structure_in_streamlit(pdb_files[0])
        else:
            st.warning("No top-ranked model found yet.")
    else:
        st.info("Run a job first to visualize the result.")
